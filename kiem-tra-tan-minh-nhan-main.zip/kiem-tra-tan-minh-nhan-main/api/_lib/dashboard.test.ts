import { describe, expect, it } from 'vitest';
import { buildExamDashboard, buildTabSwitchSummary } from './dashboard.js';

describe('buildExamDashboard', () => {
  it('aggregates pass, fail, pending, score distribution, project and level metrics', () => {
    const dashboard = buildExamDashboard([
      { project_id: 'p1', main_project: 'Công trình A', candidate_level: 'Bậc 1', correct_count: 15, incorrect_count: 5, scored_points: 8.5, total_points: 10, result: 'PASS', submit_reason: 'tab_switch' },
      { project_id: 'p1', main_project: 'Công trình A', candidate_level: 'Bậc 1', correct_count: 16, incorrect_count: 4, scored_points: 6.5, total_points: 10, result: 'FAIL', submit_reason: 'tab_switch' },
      { project_id: 'p2', main_project: 'Công trình B', candidate_level: 'Bậc 2', correct_count: 15, incorrect_count: 0, scored_points: null, total_points: 10, result: null, submit_reason: 'tab_switch' },
      { project_id: null, main_project: null, candidate_level: null, correct_count: null, incorrect_count: null, scored_points: null, total_points: null, result: null },
    ], [
      { id: 'p1', name: 'Công trình A', active: true },
      { id: 'p2', name: 'Công trình B', active: false },
      { id: 'p3', name: 'Công trình C', active: true },
    ]);

    expect(dashboard.overall).toMatchObject({
      total: 4, pass: 1, fail: 1, pending: 2, graded: 2,
      averageScore: 7.5,
    });
    expect(dashboard.overall.scoreDistribution).toEqual([
      { label: '<5', count: 0 },
      { label: '5–6.9', count: 1 },
      { label: '7–7.9', count: 0 },
      { label: '8–8.9', count: 1 },
      { label: '≥9', count: 0 },
    ]);
    expect(dashboard.projects.find((project) => project.id === 'p1')).toMatchObject({
      total: 2, pass: 1, fail: 1, averageScore: 7.5,
    });
    expect(dashboard.projects.find((project) => project.id === 'p3')).toMatchObject({ total: 0 });
    expect(dashboard.levels.find((level) => level.level === 'Bậc 1')).toMatchObject({ total: 2, pass: 1, fail: 1 });
    expect(dashboard.levels.find((level) => level.level === 'Chưa khai báo')?.total).toBe(1);
    expect(dashboard.projectLevels).toHaveLength(2);
  });

  it('counts tab-switch violations across all submitted attempts', () => {
    expect(buildTabSwitchSummary([
      { project_id: null, main_project: null, candidate_level: null, correct_count: 10, incorrect_count: 0, scored_points: 5, total_points: 10, result: 'PASS', submit_reason: 'tab_switch' },
      { project_id: null, main_project: null, candidate_level: null, correct_count: 0, incorrect_count: 10, scored_points: 0, total_points: 10, result: 'FAIL', submit_reason: 'manual' },
      { project_id: null, main_project: null, candidate_level: null, correct_count: null, incorrect_count: null, scored_points: null, total_points: null, result: null, submit_reason: 'tab_switch' },
    ])).toEqual({ total: 3, violations: 2 });
  });
});
